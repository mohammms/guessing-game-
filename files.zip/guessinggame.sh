#!/bin/bash
# guessinggame.sh
# Asks the user to guess how many files are in the current directory.

# Function: count the files (not folders, not hidden) in the current directory
count_files() {
  ls -p | grep -v / | wc -l | tr -d ' '
}

actual=$(count_files)
guess=-1

echo "Welcome to the Guessing Game!"
echo "How many files are in the current directory?"

# Loop until the user guesses correctly
while [[ $guess -ne $actual ]]
do
  read -p "Enter your guess: " response

  # Make sure the response is a non-negative whole number
  if ! [[ $response =~ ^[0-9]+$ ]]
  then
    echo "Please enter a whole number (0 or more)."
  else
    guess=$((10#$response))
    if [[ $guess -lt $actual ]]
    then
      echo "Too low! Try again."
    elif [[ $guess -gt $actual ]]
    then
      echo "Too high! Try again."
    fi
  fi
done

echo "Congratulations! You guessed it: there are $actual files in this directory."
